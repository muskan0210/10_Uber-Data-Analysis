import numpy as np
import pandas as pd
import streamlit as st

import matplotlib.pyplot as plt
# import plotly.figure_factory as ff


# start
# header=st.beta_container()
# dataset=st.beta_container()
# features=st.beta_container()
# model_training=st.beta_container()

# with dataset:
#      weatherHistory=pd.read_csv("weatherHistory.csv")
#      st.write(weatherHistory.head())

#     #  temp=pd.DataFrame(weatherHistory['Humidity'].value_counts()).head(50)
#     #  st.bar_chart(temp)


#     #  st.subheader('Weekly Demand Data')
#     #  st.write(weatherHistory)
#         #Bar Chart
#      st.bar_chart(weatherHistory['Temperature (C)'].value_counts())
#      st.bar_chart(weatherHistory['Wind Bearing (degrees)'].value_counts())
#      st.bar_chart(weatherHistory['Daily Summary'].value_counts())
#      st.bar_chart(weatherHistory['Pressure (millibars)'].value_counts())

     
     
#      df = pd.DataFrame(weatherHistory[:600], columns = ['Wind Speed (km/h)','Humidity','Pressure (millibars)', 'Wind Bearing (degrees)'])
# df.hist()
# plt.show()
# st.pyplot()

# st.line_chart(df)


# chart_data = pd.DataFrame(weatherHistory[:400], columns=['Temperature (C)','Humidity','Pressure (millibars)', 'Wind Bearing (degrees)', 'Wind Speed (km/h)'])
# st.area_chart(chart_data)



tickers=('cab_type','time_stamp','destination', 'source')
dropdown=st.multiselect('choose any option',tickers)









